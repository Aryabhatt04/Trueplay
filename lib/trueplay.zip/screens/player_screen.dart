import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:file_picker/file_picker.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:path/path.dart' as p;

import '../widgets/player_controls.dart';
import '../widgets/player_overlays.dart';
import '../services/playback_service.dart';
import '../services/history_service.dart';
import '../services/subtitle_service.dart';
import '../models/subtitle_model.dart';

class PlayerScreen extends StatefulWidget {
  final String videoPath;

  const PlayerScreen({super.key, required this.videoPath});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  VideoPlayerController? _controller;
  Timer? _hideTimer;
  Timer? _overlayHideTimer;

  Duration position = Duration.zero;
  Duration duration = Duration.zero;

  double speed = 1.0;
  bool showControls = true;
  bool showSpeedSlider = false;
  bool isLocked = false;
  bool isLandscape = false;

  // SEEK PREVIEW
  Duration previewPosition = Duration.zero;
  bool showPreview = false;
  bool _isProgressBarSeeking = false;

  // SUBTITLES
  List<Subtitle> subtitles = [];
  String currentSubtitle = '';

  // GESTURE
  double brightness = 0.5;
  double volume = 0.5;
  bool isBrightnessAdjusting = false;
  bool isVolumeAdjusting = false;

  // LONG PRESS
  bool isLongPressing = false;
  double longPressStartSpeed = 1.0;
  double? _longPressDragStartX;

  // DOUBLE TAP tracking
  Offset? _doubleTapPosition;

  int _lastUpdate = 0;

  @override
  void initState() {
    super.initState();
    VolumeController().listener((v) {
      if (mounted) setState(() => volume = v);
    });
    VolumeController().getVolume().then((v) {
      if (mounted) setState(() => volume = v);
    });
    VolumeController().showSystemUI = false;

    ScreenBrightness().current.then((b) {
      if (mounted) setState(() => brightness = b);
    });

    _initPlayer();
  }

  Future<void> _initPlayer() async {
    _controller = VideoPlayerController.file(File(widget.videoPath));
    await _controller!.initialize();

    final saved = await PlaybackService.getPosition(widget.videoPath);
    if (saved > 0) {
      await _controller!.seekTo(Duration(seconds: saved));
    }

    await HistoryService.addToHistory(widget.videoPath);
    _autoLoadSubtitles();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    _controller!.addListener(_onVideoUpdate);
    _controller!.play();
    _startHideTimer();
    if (mounted) setState(() {});
  }

  void _onVideoUpdate() {
    if (!mounted) return;
    final newPos = _controller!.value.position;
    final newDur = _controller!.value.duration;

    if ((newPos.inSeconds - position.inSeconds).abs() >= 5) {
      PlaybackService.savePosition(widget.videoPath, newPos.inSeconds);
    }

    String newSub = '';
    for (var sub in subtitles) {
      if (newPos >= sub.start && newPos <= sub.end) {
        newSub = sub.text;
        break;
      }
    }

    if (newPos != position || newDur != duration || newSub != currentSubtitle) {
      setState(() {
        position = newPos;
        duration = newDur;
        currentSubtitle = newSub;
      });
    }
  }

  Future<void> _autoLoadSubtitles() async {
    final videoDir = p.dirname(widget.videoPath);
    final videoName = p.basenameWithoutExtension(widget.videoPath);

    final candidates = [
      p.join(videoDir, '$videoName.srt'),
      p.join(videoDir, '$videoName.vtt'),
      p.join(videoDir, '${p.basename(widget.videoPath)}.srt'),
    ];

    for (var path in candidates) {
      try {
        final file = File(path);
        if (await file.exists()) {
          final content = await file.readAsString();
          final normalized =
          content.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
          final parsed = SubtitleService.parseSRT(normalized);
          if (parsed.isNotEmpty) {
            if (mounted) setState(() => subtitles = parsed);
            return;
          }
        }
      } catch (_) {}
    }
  }

  void _startHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 5), () {
      if (mounted && !_isProgressBarSeeking && !isLocked) {
        setState(() => showControls = false);
        SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      }
    });
  }

  void toggleRotation() {
    if (isLandscape) {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    } else {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    }
    setState(() => isLandscape = !isLandscape);
  }

  void setSpeed(double s) {
    s = (s * 4).round() / 4;
    s = s.clamp(0.25, 4.0);
    speed = s;
    _controller!.setPlaybackSpeed(s);
    setState(() {});
  }

  void _togglePlayPause() {
    if (_controller!.value.isPlaying) {
      _controller!.pause();
    } else {
      _controller!.play();
      _startHideTimer();
    }
    setState(() {});
  }

  String _formatTime(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    if (h > 0) return '$h:${two(m)}:${two(s)}';
    return '${two(m)}:${two(s)}';
  }

  Future<void> _loadSubtitles() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['srt', 'vtt'],
    );

    if (result != null && result.files.single.path != null) {
      try {
        final file = File(result.files.single.path!);
        final content = await file.readAsString();
        final normalized =
        content.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
        final parsed = SubtitleService.parseSRT(normalized);
        if (mounted) {
          setState(() {
            subtitles = parsed;
            currentSubtitle = '';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Loaded ${parsed.length} subtitles')),
          );
        }
      } catch (_) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to load subtitle file')),
          );
        }
      }
    }
  }

  // FIX: synchronous wrappers — no async in gesture callbacks
  void _setBrightness(double value) {
    brightness = value.clamp(0.0, 1.0);
    ScreenBrightness().setScreenBrightness(brightness).catchError((_) {});
  }

  void _setVolume(double value) {
    volume = value.clamp(0.0, 1.0);
    VolumeController().setVolume(volume);
  }

  void _hideOverlaysAfterDelay() {
    _overlayHideTimer?.cancel();
    _overlayHideTimer = Timer(const Duration(milliseconds: 800), () {
      if (mounted) {
        setState(() {
          isBrightnessAdjusting = false;
          isVolumeAdjusting = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _overlayHideTimer?.cancel();
    _controller?.removeListener(_onVideoUpdate);
    _controller?.pause();
    _controller?.dispose();
    VolumeController().removeListener();
    ScreenBrightness().resetScreenBrightness();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Widget _buildVideo() {
    return AspectRatio(
      aspectRatio: _controller!.value.aspectRatio,
      child: VideoPlayer(_controller!),
    );
  }

  // FIX: handle double tap with position tracking instead of inner GestureDetectors
  void _onDoubleTapDown(TapDownDetails details) {
    _doubleTapPosition = details.globalPosition;
  }

  void _onDoubleTap() {
    if (_doubleTapPosition == null || _controller == null) return;
    final screenWidth = MediaQuery.of(context).size.width;
    if (_doubleTapPosition!.dx < screenWidth / 2) {
      final target = position - const Duration(seconds: 10);
      _controller!.seekTo(target < Duration.zero ? Duration.zero : target);
    } else {
      final target = position + const Duration(seconds: 10);
      _controller!.seekTo(target > duration ? duration : target);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_controller == null || !_controller!.value.isInitialized) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final screenWidth = MediaQuery.of(context).size.width;

    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (didPop) {
          PlaybackService.savePosition(widget.videoPath, position.inSeconds);
          _controller?.pause();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          behavior: HitTestBehavior.opaque,

          // FIX: double tap handled here with position tracking
          onDoubleTapDown: _onDoubleTapDown,
          onDoubleTap: isLocked ? null : _onDoubleTap,

          onTap: () {
            setState(() => showControls = !showControls);
            if (showControls) {
              if (!isLocked) {
                SystemChrome.setEnabledSystemUIMode(
                  SystemUiMode.manual,
                  overlays: SystemUiOverlay.values,
                );
              }
              _startHideTimer();
            } else {
              SystemChrome.setEnabledSystemUIMode(
                  SystemUiMode.immersiveSticky);
            }
          },

          // LONG PRESS: set 2x, then horizontal drag adjusts speed
          onLongPressStart: (details) {
            if (!isLocked) {
              _longPressDragStartX = details.globalPosition.dx;
              setState(() {
                isLongPressing = true;
                longPressStartSpeed = speed;
                speed = 2.0;
                _controller!.setPlaybackSpeed(2.0);
              });
            }
          },

          onLongPressMoveUpdate: (details) {
            if (!isLocked && isLongPressing && _longPressDragStartX != null) {
              final dragDelta =
                  details.globalPosition.dx - _longPressDragStartX!;
              double newSpeed = 2.0 + (dragDelta / screenWidth) * 3.0;
              newSpeed = (newSpeed * 4).round() / 4;
              newSpeed = newSpeed.clamp(0.25, 4.0);
              if (newSpeed != speed) {
                setState(() {
                  speed = newSpeed;
                  _controller!.setPlaybackSpeed(speed);
                });
              }
            }
          },

          onLongPressEnd: (_) {
            if (isLongPressing) {
              _longPressDragStartX = null;
              setState(() {
                isLongPressing = false;
                speed = longPressStartSpeed;
                _controller!.setPlaybackSpeed(longPressStartSpeed);
              });
            }
          },

          // PAN: seek (horizontal) or brightness/volume (vertical)
          onPanStart: (details) {
            if (isLocked || isLongPressing) return;
            previewPosition = position;
            _hideTimer?.cancel();
          },

          // FIX: synchronous — no async keyword
          onPanUpdate: (details) {
            if (isLocked || isLongPressing) return;
            final now = DateTime.now().millisecondsSinceEpoch;
            if (now - _lastUpdate < 16) return;
            _lastUpdate = now;

            final dx = details.delta.dx;
            final dy = details.delta.dy;

            if (dx.abs() > dy.abs() || showPreview) {
              if (!showPreview) showPreview = true;
              final secondsPerPixel = 240.0 / screenWidth;
              previewPosition = previewPosition +
                  Duration(
                      milliseconds: (dx * secondsPerPixel * 1000).toInt());
              previewPosition = Duration(
                seconds:
                previewPosition.inSeconds.clamp(0, duration.inSeconds),
              );
              setState(() {});
            } else {
              if (details.globalPosition.dx < screenWidth / 2) {
                _setBrightness(brightness - dy / 200);
                isBrightnessAdjusting = true;
                isVolumeAdjusting = false;
              } else {
                _setVolume(volume - dy / 200);
                isVolumeAdjusting = true;
                isBrightnessAdjusting = false;
              }
              setState(() {});
            }
          },

          onPanEnd: (_) {
            if (isLocked || isLongPressing) return;
            if (showPreview) {
              _controller!.seekTo(previewPosition);
            }
            setState(() => showPreview = false);
            _hideOverlaysAfterDelay();
            _startHideTimer();
          },

          child: Stack(
            children: [
              // VIDEO
              Center(child: _buildVideo()),

              // BACK + FILENAME
              if (showControls && !isLocked)
                Positioned(
                  top: 40,
                  left: 10,
                  right: 220,
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back,
                            size: 28, color: Colors.white),
                        onPressed: () => Navigator.of(context).maybePop(),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          p.basename(widget.videoPath),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            shadows: [
                              Shadow(blurRadius: 8, color: Colors.black)
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              // TOP RIGHT: subtitles, speed, rotate
              if (showControls && !isLocked)
                Positioned(
                  top: 32,
                  right: 10,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(
                          subtitles.isNotEmpty
                              ? Icons.subtitles
                              : Icons.subtitles_outlined,
                          color: subtitles.isNotEmpty
                              ? const Color(0xFF9D00FF)
                              : Colors.white,
                        ),
                        onPressed: _loadSubtitles,
                      ),
                      IconButton(
                        icon: const Icon(Icons.speed, color: Colors.white),
                        onPressed: () => setState(
                                () => showSpeedSlider = !showSpeedSlider),
                      ),
                      IconButton(
                        icon: const Icon(Icons.screen_rotation,
                            color: Colors.white),
                        onPressed: toggleRotation,
                      ),
                    ],
                  ),
                ),

              // SEEK PREVIEW BOX (time only — no live seek)
              if (showPreview)
                Positioned(
                  top: 80,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: _SeekPreviewBox(
                      previewPosition: previewPosition,
                      duration: duration,
                      formatTime: _formatTime,
                    ),
                  ),
                ),

              // SUBTITLE TEXT
              if (currentSubtitle.isNotEmpty)
                Positioned(
                  bottom: 110,
                  left: 20,
                  right: 20,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        currentSubtitle,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          height: 1.3,
                        ),
                      ),
                    ),
                  ),
                ),

              // BRIGHTNESS / VOLUME / SPEED OVERLAYS
              PlayerOverlays(
                isLongPressing: isLongPressing,
                isSeeking: showPreview,
                isBrightness: isBrightnessAdjusting,
                isVolume: isVolumeAdjusting,
                speed: speed,
                brightness: brightness,
                volume: volume,
              ),

              // BOTTOM CONTROLS — FIX: IgnorePointer when hidden
              if (!isLocked)
                IgnorePointer(
                  ignoring: !showControls,
                  child: AnimatedOpacity(
                    opacity: showControls ? 1.0 : 0.0,
                    duration: const Duration(milliseconds: 250),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: PlayerControls(
                        isPlaying: _controller!.value.isPlaying,
                        showSpeedSlider: showSpeedSlider,
                        speed: speed,
                        position: position,
                        duration: duration,
                        isLocked: isLocked,
                        showLock: showControls,
                        onPlayPause: _togglePlayPause,
                        onSeekStart: (v) {
                          _hideTimer?.cancel();
                          setState(() {
                            _isProgressBarSeeking = true;
                            previewPosition = Duration(seconds: v.toInt());
                            showPreview = true;
                          });
                        },
                        onSeekUpdate: (v) {
                          setState(() {
                            previewPosition = Duration(seconds: v.toInt());
                            showPreview = true;
                          });
                        },
                        onSeek: (v) {
                          _controller!
                              .seekTo(Duration(seconds: v.toInt()));
                          setState(() {
                            _isProgressBarSeeking = false;
                            showPreview = false;
                          });
                          _startHideTimer();
                        },
                        onSpeedChange: setSpeed,
                        onToggleSpeed: () => setState(
                                () => showSpeedSlider = !showSpeedSlider),
                        // FIX: lock keeps controls visible, lock icon always shown
                        onToggleLock: () {
                          setState(() {
                            isLocked = !isLocked;
                            showControls = true;
                          });
                          _startHideTimer();
                        },
                      ),
                    ),
                  ),
                ),

              // FIX: lock icon always visible when locked so user can unlock
              if (isLocked)
                Positioned(
                  left: 16,
                  bottom: 40,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        isLocked = false;
                        showControls = true;
                      });
                      _startHideTimer();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.lock,
                              color: Color(0xFF9D00FF), size: 22),
                          SizedBox(width: 8),
                          Text('Tap to unlock',
                              style: TextStyle(
                                  color: Colors.white, fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// Seek preview: shows time + progress bar only (no live seekTo on controller)
class _SeekPreviewBox extends StatelessWidget {
  final Duration previewPosition;
  final Duration duration;
  final String Function(Duration) formatTime;

  const _SeekPreviewBox({
    required this.previewPosition,
    required this.duration,
    required this.formatTime,
  });

  @override
  Widget build(BuildContext context) {
    final progress = duration.inMilliseconds > 0
        ? (previewPosition.inMilliseconds / duration.inMilliseconds)
        .clamp(0.0, 1.0)
        : 0.0;

    return Container(
      width: 160,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF9D00FF), width: 1.5),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            formatTime(previewPosition),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 4,
              backgroundColor: Colors.white24,
              valueColor:
              const AlwaysStoppedAnimation<Color>(Color(0xFF9D00FF)),
            ),
          ),
        ],
      ),
    );
  }
}
